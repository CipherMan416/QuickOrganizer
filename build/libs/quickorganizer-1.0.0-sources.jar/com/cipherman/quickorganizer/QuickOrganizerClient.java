package com.cipherman.quickorganizer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1703;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class QuickOrganizerClient implements ClientModInitializer {
    private static class_304 sortKeyBinding;

    @Override
    public void onInitializeClient() {
        sortKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.quickorganizer.sort",
            class_3675.class_307.field_1668,
            GLFW.GLFW_KEY_R,
            "category.quickorganizer"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (sortKeyBinding.method_1436()) {
                sortInventory(client);
            }
        });

        QuickOrganizerMod.LOGGER.info("QuickOrganizer client initialized! Press R to sort inventory.");
    }

    private void sortInventory(class_310 client) {
        if (client.field_1724 == null) return;

        class_1703 handler = client.field_1724.field_7512;
        if (!(handler instanceof class_1723)) return;

        // 收集所有物品
        java.util.List<class_1799> items = new java.util.ArrayList<>();
        class_1723 inventory = (class_1723) handler;

        // 收集主背包物品 (slot 9-35)
        for (int i = 9; i < 36; i++) {
            class_1799 stack = inventory.method_7611(i).method_7677();
            if (!stack.method_7960()) {
                items.add(stack.method_7972());
                stack.method_7939(0);
            }
        }

        // 按物品名称排序
        items.sort((a, b) -> {
            String nameA = a.method_7964().getString();
            String nameB = b.method_7964().getString();
            return nameA.compareToIgnoreCase(nameB);
        });

        // 重新放入背包
        int slot = 9;
        for (class_1799 item : items) {
            while (item.method_7947() > 0 && slot < 36) {
                class_1799 existing = inventory.method_7611(slot).method_7677();
                if (existing.method_7960()) {
                    int canPlace = Math.min(item.method_7914(), item.method_7947());
                    class_1799 toPlace = item.method_7972();
                    toPlace.method_7939(canPlace);
                    inventory.method_7611(slot).method_53512(toPlace);
                    item.method_7934(canPlace);
                    slot++;
                } else if (class_1799.method_7984(existing, item)) {
                    int canStack = existing.method_7914() - existing.method_7947();
                    int toMove = Math.min(canStack, item.method_7947());
                    existing.method_7933(toMove);
                    item.method_7934(toMove);
                    if (item.method_7947() <= 0) slot++;
                } else {
                    slot++;
                }
            }
        }

        client.field_1724.method_7346();
    }
}
